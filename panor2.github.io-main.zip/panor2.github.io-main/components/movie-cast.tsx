"use client"

import { useRef } from "react"
import { ChevronLeft, ChevronRight, User } from "lucide-react"
import { Button } from "@/components/ui/button"

interface CastMember {
  id: number
  name: string
  character: string
  profile_path: string | null
}

export function MovieCast({ cast }: { cast: CastMember[] }) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 300
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  if (!cast || cast.length === 0) {
    return null
  }

  const displayCast = cast.slice(0, 20)

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-foreground">นักแสดงนำ</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => scroll("left")}
              className="rounded-full border-border hover:bg-secondary"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => scroll("right")}
              className="rounded-full border-border hover:bg-secondary"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-4"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {displayCast.map((member) => (
            <div
              key={member.id}
              className="flex-shrink-0 w-36 group"
            >
              <div className="relative mb-3 overflow-hidden rounded-xl">
                {member.profile_path ? (
                  <img
                    src={`https://image.tmdb.org/t/p/w300${member.profile_path}`}
                    alt={member.name}
                    className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-48 bg-muted flex items-center justify-center">
                    <User className="w-12 h-12 text-muted-foreground" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h3 className="font-medium text-foreground text-sm truncate">
                {member.name}
              </h3>
              <p className="text-xs text-muted-foreground truncate">
                {member.character || "ไม่ระบุบทบาท"}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
