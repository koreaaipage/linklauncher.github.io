"use client"

import { Star, Calendar, Clock, Play } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Movie {
  id: number
  title: string
  original_title: string
  overview: string
  backdrop_path: string
  poster_path: string
  release_date: string
  vote_average: number
  runtime: number
  genres: { id: number; name: string }[]
  videos?: {
    results: { key: string; type: string; site: string }[]
  }
}

export function MovieHero({ movie }: { movie: Movie }) {
  const backdropUrl = movie.backdrop_path
    ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}`
    : null

  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : null

  const trailer = movie.videos?.results?.find(
    (v) => v.type === "Trailer" && v.site === "YouTube"
  )

  const formatDate = (dateString: string) => {
    if (!dateString) return "ไม่ระบุ"
    const date = new Date(dateString)
    return date.toLocaleDateString("th-TH", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatRuntime = (minutes: number) => {
    if (!minutes) return "ไม่ระบุ"
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours} ชม. ${mins} นาที`
  }

  return (
    <section className="relative min-h-screen">
      {/* Background Image */}
      {backdropUrl && (
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${backdropUrl})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-background/40" />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />
        </div>
      )}

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-12 lg:py-24">
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-16 items-start">
          {/* Poster */}
          {posterUrl && (
            <div className="flex-shrink-0 mx-auto lg:mx-0">
              <div className="relative group">
                <img
                  src={posterUrl || "/placeholder.svg"}
                  alt={movie.title}
                  className="w-64 lg:w-80 rounded-xl shadow-2xl shadow-black/50 border border-border/30"
                />
                <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-black/20 to-transparent" />
              </div>
            </div>
          )}

          {/* Info */}
          <div className="flex-1 text-center lg:text-left pt-4 lg:pt-8">
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-2 text-balance">
              {movie.title}
            </h1>
            {movie.original_title !== movie.title && (
              <p className="text-xl text-muted-foreground mb-6">
                {movie.original_title}
              </p>
            )}

            {/* Genres */}
            <div className="flex flex-wrap gap-2 justify-center lg:justify-start mb-6">
              {movie.genres?.map((genre) => (
                <span
                  key={genre.id}
                  className="px-4 py-1.5 text-sm font-medium rounded-full bg-primary/20 text-primary border border-primary/30"
                >
                  {genre.name}
                </span>
              ))}
            </div>

            {/* Stats */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 text-muted-foreground mb-8">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <span className="text-lg font-semibold text-foreground">
                  {movie.vote_average?.toFixed(1)}
                </span>
                <span>/ 10</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{formatDate(movie.release_date)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span>{formatRuntime(movie.runtime)}</span>
              </div>
            </div>

            {/* Overview */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-foreground mb-3">
                เรื่องย่อ
              </h2>
              <p className="text-muted-foreground leading-relaxed max-w-2xl text-pretty">
                {movie.overview || "ไม่มีข้อมูลเรื่องย่อ"}
              </p>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              {trailer && (
                <Button
                  size="lg"
                  className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={() =>
                    window.open(
                      `https://www.youtube.com/watch?v=${trailer.key}`,
                      "_blank"
                    )
                  }
                >
                  <Play className="w-5 h-5" />
                  ดูตัวอย่าง
                </Button>
              )}
              <Button
                size="lg"
                variant="outline"
                className="gap-2 border-border hover:bg-secondary bg-transparent"
                onClick={() =>
                  window.open(
                    `https://www.themoviedb.org/movie/${movie.id}`,
                    "_blank"
                  )
                }
              >
                ดูเพิ่มเติมบน TMDB
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
