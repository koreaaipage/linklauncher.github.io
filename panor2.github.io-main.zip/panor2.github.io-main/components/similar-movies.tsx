"use client"

import { Star } from "lucide-react"
import { Card } from "@/components/ui/card"

interface Movie {
  id: number
  title: string
  poster_path: string | null
  vote_average: number
  release_date: string
}

export function SimilarMovies({ movies }: { movies: Movie[] }) {
  if (!movies || movies.length === 0) {
    return null
  }

  const displayMovies = movies.slice(0, 8)

  return (
    <section className="py-16 bg-secondary/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-foreground mb-8 text-center">
          ภาพยนตร์ที่คล้ายกัน
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 lg:gap-6">
          {displayMovies.map((movie) => (
            <Card
              key={movie.id}
              className="group bg-card/50 border-border/50 overflow-hidden cursor-pointer transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10"
              onClick={() =>
                window.open(
                  `https://www.themoviedb.org/movie/${movie.id}`,
                  "_blank"
                )
              }
            >
              <div className="relative aspect-[2/3] overflow-hidden">
                {movie.poster_path ? (
                  <img
                    src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                    alt={movie.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full bg-muted flex items-center justify-center">
                    <span className="text-muted-foreground text-sm">
                      ไม่มีรูปภาพ
                    </span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                
                {/* Rating Badge */}
                <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-md bg-black/70 backdrop-blur-sm">
                  <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                  <span className="text-xs font-medium text-foreground">
                    {movie.vote_average?.toFixed(1)}
                  </span>
                </div>
              </div>

              <div className="p-3">
                <h3 className="font-medium text-foreground text-sm line-clamp-2 mb-1">
                  {movie.title}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {movie.release_date
                    ? new Date(movie.release_date).getFullYear()
                    : "ไม่ระบุปี"}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
