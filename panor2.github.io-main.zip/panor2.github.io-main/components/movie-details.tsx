import { Film, Globe, DollarSign, TrendingUp } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface Movie {
  id: number
  status: string
  original_language: string
  budget: number
  revenue: number
  production_companies: { id: number; name: string; logo_path: string | null }[]
  production_countries: { iso_3166_1: string; name: string }[]
  spoken_languages: { iso_639_1: string; name: string; english_name: string }[]
}

export function MovieDetails({ movie }: { movie: Movie }) {
  const formatCurrency = (amount: number) => {
    if (!amount || amount === 0) return "ไม่ระบุ"
    return new Intl.NumberFormat("th-TH", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getStatusThai = (status: string) => {
    const statusMap: Record<string, string> = {
      Released: "เข้าฉายแล้ว",
      "Post Production": "หลังการผลิต",
      "In Production": "กำลังผลิต",
      Planned: "วางแผน",
      Canceled: "ยกเลิก",
      Rumored: "ข่าวลือ",
    }
    return statusMap[status] || status
  }

  const getLanguageThai = (lang: string) => {
    const langMap: Record<string, string> = {
      th: "ไทย",
      en: "อังกฤษ",
      ja: "ญี่ปุ่น",
      ko: "เกาหลี",
      zh: "จีน",
    }
    return langMap[lang] || lang
  }

  const details = [
    {
      icon: Film,
      label: "สถานะ",
      value: getStatusThai(movie.status),
    },
    {
      icon: Globe,
      label: "ภาษาต้นฉบับ",
      value: getLanguageThai(movie.original_language),
    },
    {
      icon: DollarSign,
      label: "งบประมาณ",
      value: formatCurrency(movie.budget),
    },
    {
      icon: TrendingUp,
      label: "รายได้",
      value: formatCurrency(movie.revenue),
    },
  ]

  return (
    <section className="py-16 bg-secondary/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-foreground mb-8 text-center">
          รายละเอียดภาพยนตร์
        </h2>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {details.map((detail, index) => (
            <Card
              key={index}
              className="bg-card/50 border-border/50 backdrop-blur-sm"
            >
              <CardContent className="p-6 text-center">
                <detail.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                <p className="text-sm text-muted-foreground mb-1">
                  {detail.label}
                </p>
                <p className="text-lg font-semibold text-foreground">
                  {detail.value}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Production Companies */}
        {movie.production_companies?.length > 0 && (
          <div className="mb-12">
            <h3 className="text-xl font-semibold text-foreground mb-6 text-center">
              บริษัทผู้ผลิต
            </h3>
            <div className="flex flex-wrap justify-center gap-6">
              {movie.production_companies.map((company) => (
                <div
                  key={company.id}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg bg-card/50 border border-border/50"
                >
                  {company.logo_path ? (
                    <img
                      src={`https://image.tmdb.org/t/p/w200${company.logo_path}`}
                      alt={company.name}
                      className="h-8 w-auto object-contain brightness-0 invert opacity-80"
                    />
                  ) : (
                    <span className="text-foreground font-medium">
                      {company.name}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Languages */}
        {movie.spoken_languages?.length > 0 && (
          <div>
            <h3 className="text-xl font-semibold text-foreground mb-4 text-center">
              ภาษาพากย์
            </h3>
            <div className="flex flex-wrap justify-center gap-3">
              {movie.spoken_languages.map((lang) => (
                <span
                  key={lang.iso_639_1}
                  className="px-4 py-2 rounded-full bg-muted text-muted-foreground border border-border/50"
                >
                  {lang.name || lang.english_name}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
