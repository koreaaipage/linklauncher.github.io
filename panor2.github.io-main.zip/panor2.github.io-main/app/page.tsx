import { MovieHero } from "@/components/movie-hero"
import { MovieDetails } from "@/components/movie-details"
import { MovieCast } from "@/components/movie-cast"
import { SimilarMovies } from "@/components/similar-movies"
import { Footer } from "@/components/footer"

const TMDB_API_KEY = "bd51681eae50b9c4e9ef389ce8b12771"

async function searchMovie(query: string) {
  const res = await fetch(
    `https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&language=th-TH`
  )
  const data = await res.json()
  return data.results?.[0]
}

async function getMovieDetails(movieId: number) {
  const res = await fetch(
    `https://api.themoviedb.org/3/movie/${movieId}?api_key=${TMDB_API_KEY}&language=th-TH&append_to_response=credits,videos,similar`
  )
  return res.json()
}

export default async function MoviePage() {
  const searchResult = await searchMovie("พนอ 2")
  
  if (!searchResult) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">ไม่พบภาพยนตร์</h1>
          <p className="text-muted-foreground">กรุณาลองใหม่อีกครั้ง</p>
        </div>
      </main>
    )
  }

  const movie = await getMovieDetails(searchResult.id)

  return (
    <main className="min-h-screen bg-background">
      <MovieHero movie={movie} />
      <MovieDetails movie={movie} />
      <MovieCast cast={movie.credits?.cast || []} />
      <SimilarMovies movies={movie.similar?.results || []} />
      <Footer />
    </main>
  )
}
