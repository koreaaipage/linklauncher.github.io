import React from "react"
import type { Metadata } from 'next'
import { Noto_Sans_Thai } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const notoSansThai = Noto_Sans_Thai({ 
  subsets: ["thai", "latin"],
  weight: ["300", "400", "500", "600", "700"]
});

export const metadata: Metadata = {
  title: 'พนอ 2 - ภาพยนตร์ไทย',
  description: 'ข้อมูลภาพยนตร์ พนอ 2 - ภาพยนตร์สยองขวัญไทย',
  generator: 'v0.app',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="th" className="dark">
      <body className={`${notoSansThai.className} antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
